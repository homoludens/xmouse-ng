# Approved changes — 2026-10-26, latest revision

- App display name: XMouse-NG.
- Hamburger menu contains settings and management.
- Exactly two main tabs: Touchpad and Actions; no Keys screen.
- Type on computer is an INLINE text field with an adjacent Send button on both pages.
- Do not open a typing page, bottom sheet, or dialog.
- Preserve the draft across page changes and reconnects; disable blank/disconnected sends.
- Remove Gyro from the redesigned UI, including settings.
- Make Connect/Disconnect a clearly visible labeled header button with distinct connection states.
- Preserve former key groups as optional Action layouts/presets.
- Preserve existing hosts, custom layouts/actions, scripts, and transport behavior.

The current design-reference.html, DESIGN_SPEC.md, and IMPLEMENTATION_PROMPT.md include these changes.
